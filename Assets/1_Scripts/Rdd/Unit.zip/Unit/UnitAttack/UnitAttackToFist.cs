using UnityEngine;

public class UnitAttackToFist : MonoBehaviour, IAttack
{
    public void OnAttack(PlayerInputAttackData data, UnitAttackOption option)
    {
        
    }
}
