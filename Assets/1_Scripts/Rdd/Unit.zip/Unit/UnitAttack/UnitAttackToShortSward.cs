using UnityEngine;

public class UnitAttackToShortSward : MonoBehaviour, IAttack
{
    public void OnAttack(PlayerInputAttackData data, UnitAttackOption option)
    {
        
    }
}
