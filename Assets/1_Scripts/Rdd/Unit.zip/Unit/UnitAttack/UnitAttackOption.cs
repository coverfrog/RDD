using System;
using UnityEngine;

[Serializable]
public class UnitAttackOption
{
    public float attackSpeed;
}
