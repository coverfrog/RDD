
using UnityEngine;

public enum UnitAttackType
{
    ToNone,
    ToBodySlam,
    ToFist,
    ToShortSward,
}
