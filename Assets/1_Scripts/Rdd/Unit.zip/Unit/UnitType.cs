using UnityEngine;

public enum UnitType 
{
    ToNone,
    ToPlayer,
    ToNpc
}
