using System;
using UnityEngine;

[Serializable]
public class UnitMoveOption
{
    public float moveSpeed = 3.0f;
}
