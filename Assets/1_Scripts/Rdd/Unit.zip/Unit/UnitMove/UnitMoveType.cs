public enum UnitMoveType 
{
    ToNone,
    ToDir,
    ToDirNavMesh,
    ToPoint,
    ToPointNavMesh
}
